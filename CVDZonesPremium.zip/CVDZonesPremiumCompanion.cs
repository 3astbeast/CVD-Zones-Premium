#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private CVDZonesPremiumCompanion[] cacheCVDZonesPremiumCompanion;
		private CVDZonesPremium[] cacheCVDZonesPremium;

		
		public CVDZonesPremiumCompanion CVDZonesPremiumCompanion(BarsPeriodType sourceBarsPeriodType, int sourceBarsPeriodValue, int opacityOverride, bool hideActiveCandle, bool showStatusLabel)
		{
			return CVDZonesPremiumCompanion(Input, sourceBarsPeriodType, sourceBarsPeriodValue, opacityOverride, hideActiveCandle, showStatusLabel);
		}

		public CVDZonesPremium CVDZonesPremium(double thresholdPct, bool useVWMidpoint, bool useNormApprox, int heatmapOpacity, bool hideActiveCandle)
		{
			return CVDZonesPremium(Input, thresholdPct, useVWMidpoint, useNormApprox, heatmapOpacity, hideActiveCandle);
		}


		
		public CVDZonesPremiumCompanion CVDZonesPremiumCompanion(ISeries<double> input, BarsPeriodType sourceBarsPeriodType, int sourceBarsPeriodValue, int opacityOverride, bool hideActiveCandle, bool showStatusLabel)
		{
			if (cacheCVDZonesPremiumCompanion != null)
				for (int idx = 0; idx < cacheCVDZonesPremiumCompanion.Length; idx++)
					if (cacheCVDZonesPremiumCompanion[idx].SourceBarsPeriodType == sourceBarsPeriodType && cacheCVDZonesPremiumCompanion[idx].SourceBarsPeriodValue == sourceBarsPeriodValue && cacheCVDZonesPremiumCompanion[idx].OpacityOverride == opacityOverride && cacheCVDZonesPremiumCompanion[idx].HideActiveCandle == hideActiveCandle && cacheCVDZonesPremiumCompanion[idx].ShowStatusLabel == showStatusLabel && cacheCVDZonesPremiumCompanion[idx].EqualsInput(input))
						return cacheCVDZonesPremiumCompanion[idx];
			return CacheIndicator<CVDZonesPremiumCompanion>(new CVDZonesPremiumCompanion(){ SourceBarsPeriodType = sourceBarsPeriodType, SourceBarsPeriodValue = sourceBarsPeriodValue, OpacityOverride = opacityOverride, HideActiveCandle = hideActiveCandle, ShowStatusLabel = showStatusLabel }, input, ref cacheCVDZonesPremiumCompanion);
		}

		public CVDZonesPremium CVDZonesPremium(ISeries<double> input, double thresholdPct, bool useVWMidpoint, bool useNormApprox, int heatmapOpacity, bool hideActiveCandle)
		{
			if (cacheCVDZonesPremium != null)
				for (int idx = 0; idx < cacheCVDZonesPremium.Length; idx++)
					if (cacheCVDZonesPremium[idx].ThresholdPct == thresholdPct && cacheCVDZonesPremium[idx].UseVWMidpoint == useVWMidpoint && cacheCVDZonesPremium[idx].UseNormApprox == useNormApprox && cacheCVDZonesPremium[idx].HeatmapOpacity == heatmapOpacity && cacheCVDZonesPremium[idx].HideActiveCandle == hideActiveCandle && cacheCVDZonesPremium[idx].EqualsInput(input))
						return cacheCVDZonesPremium[idx];
			return CacheIndicator<CVDZonesPremium>(new CVDZonesPremium(){ ThresholdPct = thresholdPct, UseVWMidpoint = useVWMidpoint, UseNormApprox = useNormApprox, HeatmapOpacity = heatmapOpacity, HideActiveCandle = hideActiveCandle }, input, ref cacheCVDZonesPremium);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.CVDZonesPremiumCompanion CVDZonesPremiumCompanion(BarsPeriodType sourceBarsPeriodType, int sourceBarsPeriodValue, int opacityOverride, bool hideActiveCandle, bool showStatusLabel)
		{
			return indicator.CVDZonesPremiumCompanion(Input, sourceBarsPeriodType, sourceBarsPeriodValue, opacityOverride, hideActiveCandle, showStatusLabel);
		}

		public Indicators.CVDZonesPremium CVDZonesPremium(double thresholdPct, bool useVWMidpoint, bool useNormApprox, int heatmapOpacity, bool hideActiveCandle)
		{
			return indicator.CVDZonesPremium(Input, thresholdPct, useVWMidpoint, useNormApprox, heatmapOpacity, hideActiveCandle);
		}


		
		public Indicators.CVDZonesPremiumCompanion CVDZonesPremiumCompanion(ISeries<double> input , BarsPeriodType sourceBarsPeriodType, int sourceBarsPeriodValue, int opacityOverride, bool hideActiveCandle, bool showStatusLabel)
		{
			return indicator.CVDZonesPremiumCompanion(input, sourceBarsPeriodType, sourceBarsPeriodValue, opacityOverride, hideActiveCandle, showStatusLabel);
		}

		public Indicators.CVDZonesPremium CVDZonesPremium(ISeries<double> input , double thresholdPct, bool useVWMidpoint, bool useNormApprox, int heatmapOpacity, bool hideActiveCandle)
		{
			return indicator.CVDZonesPremium(input, thresholdPct, useVWMidpoint, useNormApprox, heatmapOpacity, hideActiveCandle);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.CVDZonesPremiumCompanion CVDZonesPremiumCompanion(BarsPeriodType sourceBarsPeriodType, int sourceBarsPeriodValue, int opacityOverride, bool hideActiveCandle, bool showStatusLabel)
		{
			return indicator.CVDZonesPremiumCompanion(Input, sourceBarsPeriodType, sourceBarsPeriodValue, opacityOverride, hideActiveCandle, showStatusLabel);
		}

		public Indicators.CVDZonesPremium CVDZonesPremium(double thresholdPct, bool useVWMidpoint, bool useNormApprox, int heatmapOpacity, bool hideActiveCandle)
		{
			return indicator.CVDZonesPremium(Input, thresholdPct, useVWMidpoint, useNormApprox, heatmapOpacity, hideActiveCandle);
		}


		
		public Indicators.CVDZonesPremiumCompanion CVDZonesPremiumCompanion(ISeries<double> input , BarsPeriodType sourceBarsPeriodType, int sourceBarsPeriodValue, int opacityOverride, bool hideActiveCandle, bool showStatusLabel)
		{
			return indicator.CVDZonesPremiumCompanion(input, sourceBarsPeriodType, sourceBarsPeriodValue, opacityOverride, hideActiveCandle, showStatusLabel);
		}

		public Indicators.CVDZonesPremium CVDZonesPremium(ISeries<double> input , double thresholdPct, bool useVWMidpoint, bool useNormApprox, int heatmapOpacity, bool hideActiveCandle)
		{
			return indicator.CVDZonesPremium(input, thresholdPct, useVWMidpoint, useNormApprox, heatmapOpacity, hideActiveCandle);
		}

	}
}

#endregion
